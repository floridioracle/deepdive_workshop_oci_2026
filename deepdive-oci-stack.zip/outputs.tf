output "autonomous_database_id" {
  description = "OCID of the created Autonomous AI Database."
  value       = oci_database_autonomous_database.deepdive_autonomous.id
}

output "autonomous_database_state" {
  description = "Lifecycle state of the Autonomous AI Database."
  value       = oci_database_autonomous_database.deepdive_autonomous.state
}

output "aidp_id" {
  description = "OCID of the created AI Data Platform."
  value       = var.create_aidp ? oci_ai_data_platform_ai_data_platform.deepdive_aidp[0].id : null
}

output "aidp_state" {
  description = "Lifecycle state of the AI Data Platform."
  value       = var.create_aidp ? oci_ai_data_platform_ai_data_platform.deepdive_aidp[0].state : null
}

output "aidp_policy_id" {
  description = "IAM policy OCID created for AIDP service (if enabled)."
  value       = var.create_aidp && var.create_aidp_policy ? oci_identity_policy.aidp_service_policy[0].id : null
}

output "adb_resource_principal_dynamic_group_id" {
  description = "Dynamic group OCID created for the Autonomous Database resource principal (if enabled)."
  value       = var.create_adb_resource_principal_policy ? oci_identity_dynamic_group.adb_resource_principal[0].id : null
}

output "adb_resource_principal_policy_id" {
  description = "IAM policy OCID created for the Autonomous Database resource principal (if enabled)."
  value       = var.create_adb_resource_principal_policy ? oci_identity_policy.adb_resource_principal[0].id : null
}

output "admin_password" {
  description = "Admin password used for the Autonomous DB."
  value       = var.admin_password
  sensitive   = true
}

output "wallet_base64" {
  description = "Wallet zip content (base64)."
  value       = oci_database_autonomous_database_wallet.deepdive_wallet.content
  sensitive   = true
}

output "wallet_file_path" {
  description = "Wallet local path when write_wallet_file=true."
  value       = var.write_wallet_file ? local_sensitive_file.wallet_zip[0].filename : null
}
