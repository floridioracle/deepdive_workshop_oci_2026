variable "region" {
  description = "OCI region. Keep null in stack to use the stack region/environment."
  type        = string
  default     = null
}

variable "compartment_id" {
  description = "Compartment OCID where resources will be created."
  type        = string
}

variable "tenancy_ocid" {
  description = "Tenancy OCID (root compartment) where IAM policy will be created."
  type        = string
}

variable "autonomous_display_name" {
  description = "Autonomous AI Database display name."
  type        = string
  default     = "DeepDiveAutonomousDatabase"
}

variable "autonomous_db_name" {
  description = "Autonomous database name (up to 14 chars, alphanumeric)."
  type        = string
  default     = "DEEPDIVEAIDB"
}

variable "autonomous_db_version" {
  description = "Autonomous database version."
  type        = string
  default     = "26ai"
}

variable "autonomous_storage_gb" {
  description = "Autonomous database storage in GB."
  type        = number
  default     = 100
}

variable "admin_password" {
  description = "Admin password for Autonomous (admin). Requested default for workshop."
  type        = string
  default     = "Workshop@123"
  sensitive   = true
}

variable "aidp_display_name" {
  description = "AI Data Platform display name."
  type        = string
  default     = "DeepDiveAIDP"
}

variable "aidp_workspace_name" {
  description = "Default workspace name for AI Data Platform."
  type        = string
  default     = "DeepDiveWorkspace"
}

variable "create_aidp" {
  description = "If false, skips AIDP creation."
  type        = bool
  default     = true
}

variable "create_aidp_policy" {
  description = "If true, creates IAM policy needed by AIDP service."
  type        = bool
  default     = true
}

variable "aidp_policy_name" {
  description = "IAM policy name for AIDP service access."
  type        = string
  default     = "DeepDiveAIDPServicePolicy"
}

variable "aidp_policy_wait_duration" {
  description = "Wait time for IAM policy propagation before creating AIDP."
  type        = string
  default     = "45s"
}

variable "create_adb_resource_principal_policy" {
  description = "If true, creates the dynamic group and IAM policy needed by Autonomous Database resource principal for Select AI, RAG, Object Storage, Document Understanding, and secrets."
  type        = bool
  default     = true
}

variable "adb_resource_principal_dynamic_group_name" {
  description = "Dynamic group name for the Autonomous Database resource principal."
  type        = string
  default     = "DeepDiveAdbResourcePrincipal"
}

variable "adb_resource_principal_policy_name" {
  description = "IAM policy name for Autonomous Database resource principal access."
  type        = string
  default     = "DeepDiveAdbResourcePrincipalPolicy"
}

variable "wallet_generate_type" {
  description = "Wallet generation type."
  type        = string
  default     = "SINGLE"
}

variable "wallet_password" {
  description = "Wallet password. If null, admin_password is used."
  type        = string
  default     = null
  sensitive   = true
}

variable "write_wallet_file" {
  description = "If true, writes wallet zip locally."
  type        = bool
  default     = false
}

variable "wallet_file_path" {
  description = "Local path to save wallet zip when write_wallet_file=true."
  type        = string
  default     = "./autonomous_wallet.zip"
}
