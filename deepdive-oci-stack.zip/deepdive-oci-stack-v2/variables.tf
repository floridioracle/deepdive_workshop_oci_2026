variable "region" {
  description = "OCI region. Keep null in stack to use the stack region/environment."
  type        = string
  default     = null
}

variable "compartment_id" {
  description = "Compartment OCID where resources will be created."
  type        = string
}

variable "tenancy_ocid" {
  description = "Tenancy OCID (root compartment) where IAM policy will be created."
  type        = string
}

variable "autonomous_display_name" {
  description = "Autonomous AI Database display name."
  type        = string
  default     = "DeepDiveAutonomousDatabase"
}

variable "autonomous_db_name" {
  description = "Autonomous database name (up to 14 chars, alphanumeric)."
  type        = string
  default     = "DEEPDIVEAIDB"
}

variable "autonomous_db_version" {
  description = "Autonomous database version."
  type        = string
  default     = "26ai"
}

variable "autonomous_storage_gb" {
  description = "Autonomous database storage in GB."
  type        = number
  default     = 100
}

variable "admin_password" {
  description = "Admin password for Autonomous Database admin user."
  type        = string
  default     = "Workshop@123"
  sensitive   = true

  validation {
    condition = (
      length(var.admin_password) >= 8 &&
      can(regex("[A-Za-z]", var.admin_password)) &&
      (
        can(regex("[0-9]", var.admin_password)) ||
        can(regex("[^A-Za-z0-9]", var.admin_password))
      )
    )
    error_message = "admin_password must be at least 8 characters and include letters plus numbers or special characters."
  }
}

variable "aidp_display_name" {
  description = "AI Data Platform display name."
  type        = string
  default     = "DeepDiveAIDP"
}

variable "aidp_workspace_name" {
  description = "Default workspace name for AI Data Platform."
  type        = string
  default     = "DeepDiveWorkspace"
}

variable "create_aidp" {
  description = "If false, skips AIDP creation."
  type        = bool
  default     = true
}

variable "create_aidp_policy" {
  description = "If true, creates IAM policy needed by AIDP service."
  type        = bool
  default     = true
}

variable "aidp_policy_name" {
  description = "IAM policy name for AIDP service access."
  type        = string
  default     = "DeepDiveAIDPServicePolicy"
}

variable "aidp_policy_wait_duration" {
  description = "Wait time for IAM policy propagation before creating AIDP."
  type        = string
  default     = "180s"
}

variable "wallet_generate_type" {
  description = "Wallet generation type."
  type        = string
  default     = "SINGLE"
}

variable "wallet_password" {
  description = "Wallet password. If null, admin_password is used."
  type        = string
  default     = null
  sensitive   = true

  validation {
    condition = (
      var.wallet_password == null ||
      (
        length(var.wallet_password) >= 8 &&
        can(regex("[A-Za-z]", var.wallet_password)) &&
        (
          can(regex("[0-9]", var.wallet_password)) ||
          can(regex("[^A-Za-z0-9]", var.wallet_password))
        )
      )
    )
    error_message = "wallet_password must be at least 8 characters and include letters plus numbers or special characters."
  }
}

variable "write_wallet_file" {
  description = "If true, writes wallet zip locally."
  type        = bool
  default     = false
}

variable "wallet_file_path" {
  description = "Local path to save wallet zip when write_wallet_file=true."
  type        = string
  default     = "./autonomous_wallet.zip"
}

variable "aidp_create_timeout" {
  description = "Timeout for AI Data Platform creation."
  type        = string
  default     = "2h"
}

variable "aidp_delete_timeout" {
  description = "Timeout for AI Data Platform deletion."
  type        = string
  default     = "2h"
}