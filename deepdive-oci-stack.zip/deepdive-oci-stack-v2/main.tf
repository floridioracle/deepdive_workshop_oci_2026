locals {
  effective_wallet_password = var.wallet_password != null ? var.wallet_password : var.admin_password
  aidp_policy_statements = [
    "allow any-user TO {AUTHENTICATION_INSPECT, DOMAIN_INSPECT, DOMAIN_READ, DYNAMIC_GROUP_INSPECT, GROUP_INSPECT, GROUP_MEMBERSHIP_INSPECT, USER_INSPECT, USER_READ} IN TENANCY where all {request.principal.type='aidataplatform'}",
    "allow any-user to manage log-groups in compartment id ${var.compartment_id} where ALL { request.principal.type='aidataplatform' }",
    "allow any-user to read log-content in compartment id ${var.compartment_id} where ALL { request.principal.type='aidataplatform' }",
    "allow any-user to use metrics in compartment id ${var.compartment_id} where ALL {request.principal.type='aidataplatform', target.metrics.namespace='oracle_aidataplatform'}",
    "allow any-user to manage buckets in compartment id ${var.compartment_id} where all { request.principal.type='aidataplatform', any {request.permission = 'BUCKET_CREATE', request.permission = 'BUCKET_INSPECT', request.permission = 'BUCKET_READ', request.permission = 'BUCKET_UPDATE'}}",
    "allow any-user to {TAG_NAMESPACE_USE} in tenancy where all {request.principal.type = 'aidataplatform'}",
    "allow any-user to manage buckets in compartment id ${var.compartment_id} where all { request.principal.id=target.resource.tag.orcl-aidp.governingAidpId, any {request.permission = 'BUCKET_DELETE', request.permission = 'PAR_MANAGE', request.permission = 'RETENTION_RULE_LOCK', request.permission = 'RETENTION_RULE_MANAGE'} }",
    "allow any-user to read objectstorage-namespaces in compartment id ${var.compartment_id} where all { request.principal.type='aidataplatform', any {request.permission = 'OBJECTSTORAGE_NAMESPACE_READ'}}",
    "allow any-user to manage objects in compartment id ${var.compartment_id} where all { request.principal.id=target.bucket.system-tag.orcl-aidp.governingAidpId }"
  ]
}

resource "oci_database_autonomous_database" "deepdive_autonomous" {
  compartment_id = var.compartment_id
  db_name        = var.autonomous_db_name
  display_name   = var.autonomous_display_name

  admin_password          = var.admin_password
  db_workload             = "OLTP"
  db_version              = var.autonomous_db_version
  compute_model           = "ECPU"
  compute_count           = 2
  data_storage_size_in_gb = var.autonomous_storage_gb
  license_model           = "LICENSE_INCLUDED"
  source                  = "NONE"
}

resource "oci_identity_policy" "aidp_service_policy" {
  count = var.create_aidp && var.create_aidp_policy ? 1 : 0

  compartment_id = var.tenancy_ocid
  name           = var.aidp_policy_name
  description    = "Policy for AI Data Platform service operations in DeepDive workshop."
  statements     = local.aidp_policy_statements
}

resource "time_sleep" "wait_iam_propagation" {
  count = var.create_aidp && var.create_aidp_policy ? 1 : 0

  create_duration = var.aidp_policy_wait_duration

  depends_on = [oci_identity_policy.aidp_service_policy]
}

resource "oci_database_autonomous_database_wallet" "deepdive_wallet" {
  autonomous_database_id = oci_database_autonomous_database.deepdive_autonomous.id
  password               = local.effective_wallet_password
  generate_type          = var.wallet_generate_type
  base64_encode_content  = true
}

resource "oci_ai_data_platform_ai_data_platform" "deepdive_aidp" {
  count = var.create_aidp ? 1 : 0

  compartment_id         = var.compartment_id
  display_name           = var.aidp_display_name
  default_workspace_name = var.aidp_workspace_name

  depends_on = [
    time_sleep.wait_iam_propagation,
    oci_database_autonomous_database.deepdive_autonomous,
    oci_database_autonomous_database_wallet.deepdive_wallet
  ]

  timeouts {
    create = var.aidp_create_timeout
    delete = var.aidp_delete_timeout
  }
}

resource "local_sensitive_file" "wallet_zip" {
  count          = var.write_wallet_file ? 1 : 0
  filename       = var.wallet_file_path
  content_base64 = oci_database_autonomous_database_wallet.deepdive_wallet.content
}
