# DeepDive Terraform Setup

Creates:
- Autonomous AI Database
- AI Data Platform (AIDP)
- Autonomous wallet output (base64) and optional local wallet zip file

## 1) OCI Resource Manager Stack (recommended)

Use this folder as your stack source:
- `DeepDive Workshop/terraform`

Set stack variables at minimum:
- `compartment_id`
- `tenancy_ocid`
- `region` (optional; leave empty/null to use stack region)

ADB compute is fixed in code:
- `compute_model = "ECPU"`
- `compute_count = 2`
- `data_storage_size_in_gb = 100`

## 2) Local Terraform run

Run:

```bash
terraform init
terraform plan -var-file=terraform.tfvars
terraform apply -var-file=terraform.tfvars
```

## Outputs

- `autonomous_database_id`
- `aidp_id`
- `wallet_base64` (sensitive)
- `admin_password` (sensitive, default requested: `Workshop@123`)
- `wallet_file_path` (when `write_wallet_file=true`)

## AIDP policy note

This stack now creates AIDP IAM policy automatically in tenancy root before AIDP creation.

Useful toggles:
- `create_aidp = false` to skip AIDP
- `create_aidp_policy = false` if policy already exists
- `aidp_policy_wait_duration = "45s"` (increase if IAM propagation is slow)

Then apply ADB first and enable AIDP after IAM policies are adjusted.

To read sensitive outputs:

```bash
terraform output -raw admin_password
terraform output -raw wallet_base64
```

To decode wallet locally:

```bash
terraform output -raw wallet_base64 > wallet.b64
base64 -d wallet.b64 > wallet.zip
```
