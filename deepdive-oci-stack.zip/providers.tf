provider "oci" {
  # For OCI Resource Manager stacks, do not hardcode auth mode.
  # The service injects runtime credentials automatically.
  region = var.region
}
